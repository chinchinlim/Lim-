<html>
<title> Compilation </title> <br>
<head> <!--Functions placed here --> </head>
<body>

<center><h2>first adjustment</h2></center>
<hr>

<table align="center" width="90%" border="0">
	<tr>
		<th><a href="htmlreview.php"> 	    Html Review </a></th>
		<th><a href="htmlforms.php"> 		Html Forms  </a></th>
		<th><a href="postform.php"> 		Post Form   </a></th>
		<th><a href="getform.php"> 		    Get Form    </a></th>
		<th><a href="ifcondition.php">      IfCondition </a></th>
		<th><a href="samepage.php"> 		SamePage    </a></th>
		<th><a href="switchdemo.php">       SwitchDemo  </a></th>
		<th><a href="loops.php"> 			Loops       </a></th>
		<th><a href="activity1.php"> 		Activity1   </a></th>
		<th><a href="activity2.php"> 		Activity2   </a></th>
		<th><a href="activity3.php"> 		Activity3   </a></th>

	</tr>
</table>
<hr>
<br>
</body>
</html>
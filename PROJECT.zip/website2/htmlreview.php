<html>
<title> Gene </title>
<body>
<?php include("index.php");
?>
	<center> HTML Review </center> <br>
	<hr align="center" width="80%"> <br> <!--Underline-->
	
	<font color="blue" size="14" face="Times"> I am colorful.</font> <br> <br>
	<!--Arial, Times, Verdana, Serifs, Courier New-->

	<b><u><i> Good day </i> </u> </b> <br>

<h1> hello </h1> <br>
<h2> hello </h2> <br>
<h3> hello </h3> <br>
<h4> hello </h4> <br>
<h5> hello </h5> <br>

<table align="center" width="70" border="1">
<tr>
	<th> column1 </th> <!--th is title header -->
	<th> column2 </th>
	<th> column3 </th>
</tr>

<tr>
	<td> 1 </td> <!--td is title division -->
	<td> 2 </td>
	<td> 3 </td>
</tr>

<tr>
	<td> 4 </td>
	<td> 5 </td>
	<td> 6 </td>
</tr>

</table>
</body> 
</html>
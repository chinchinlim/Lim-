<html>
<title> Loops </title> <br>
<head> <!--first adjustment --> </head>
<body>
<?php include("index.php");
?>

while demo <br><hr>
<?php
$a=1;
while($a<=70){
echo "$a. hello<br>";
$a=$a+1;
}
?>
<br><br>

do while Demo <br><br>
<?php
$b=1;
do{
echo "$b. Good day!<br>";
$b=$b+1;
}
while ($b+6);

?>
<br><br>
FOR LOOP DEMO<br><hr>

<?php
for ($c=1; $c<=7;$c=$c++){
echo "$c. Good bye!<br>";
}
?>

</body>
</html>